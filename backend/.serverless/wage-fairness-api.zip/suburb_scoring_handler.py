import json
import logging
import pymysql.cursors
import re

# 设置日志记录
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# 数据库配置
DB_CONFIG = {
    'host': 'fairwageaustralia.ct08osmucf2b.ap-southeast-2.rds.amazonaws.com',
    'user': 'admin',
    'password': 'fairwageaustralia',
    'port': 3306,
    'database': 'fairwageaustralia',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

# 评分权重配置
SCORING_WEIGHTS = {
    'safety': 0.20,         # 安全评分权重 20%
    'cost_of_living': 0.25, # 生活成本权重 25%
    'transport': 0.20,      # 交通便利权重 20%
    'child_care': 0.20,     # 孩子保障权重 20%
    'industry': 0.15        # 行业匹配权重 15%
}

def normalize_text(text):
    """标准化文本：去除标点、空格、转小写"""
    if not text:
        return ""
    return re.sub(r'[^a-zA-Z0-9]', '', text.lower())

def get_sal_code_by_suburb(suburb_name):
    """
    通过suburb名称获取对应的SAL_CODE21
    """
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 从suburb-postcode映射表获取SAL_CODE21
            sql_mapping = """
            SELECT SAL_CODE21, postcode
            FROM epic3_mapping_suburb_postcode 
            WHERE UPPER(TRIM(SAL_NAME21)) = UPPER(TRIM(%s))
            LIMIT 1
            """
            cursor.execute(sql_mapping, (suburb_name,))
            mapping_result = cursor.fetchone()
            
            if not mapping_result:
                logger.error(f"在映射表中未找到suburb: {suburb_name}")
                return None
                
            sal_code = mapping_result['SAL_CODE21']
            logger.info(f"找到SAL_CODE21: {sal_code} for suburb: {suburb_name}")
            
            # 从房价表获取房价数据
            house_price = 0
            try:
                sql_house = "SELECT `2024` as price FROM epic3_house_prices WHERE SAL_CODE21 = %s LIMIT 1"
                cursor.execute(sql_house, (sal_code,))
                house_result = cursor.fetchone()
                
                if house_result and house_result['price'] is not None:
                    house_price = float(house_result['price'])
                    logger.info(f"找到房价数据: ${house_price}")
                else:
                    logger.warning(f"未找到SAL_CODE21={sal_code}的房价数据")
                    
            except Exception as house_error:
                logger.error(f"查询房价时出错: {str(house_error)}")
            
            return {
                'sal_code': sal_code,
                'postcode': mapping_result['postcode'],
                'house_price_2024': house_price
            }
            
    except Exception as e:
        logger.error(f"获取SAL编码时出错: {str(e)}")
        return None
    finally:
        if connection:
            connection.close()

def calculate_safety_score(sal_code):
    """
    基于人口和犯罪数据计算安全评分
    使用犯罪率而不是绝对犯罪数量
    """
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 1. 获取人口数据
            sql_population = """
            SELECT Tot_P_P as population
            FROM epic3_p 
            WHERE _CODE_2021 = %s
            """
            cursor.execute(sql_population, (sal_code,))
            pop_result = cursor.fetchone()
            
            population = int(pop_result['population']) if pop_result and pop_result['population'] else 0
            

            crime_result = cursor.fetchone()
            
            total_crimes = int(crime_result['total_crimes']) if crime_result and crime_result['total_crimes'] else 0
            
            # 3. 计算安全评分
            if population < 50:
                # 人口太少，犯罪率不可靠，给中等评分
                safety_score = 60.0
                crime_rate = 0
                calculation = f"人口{population}过少，使用默认评分60分"
                reliability = "low"
            elif population == 0:
                # 无人口数据
                safety_score = 50.0  
                crime_rate = 0
                calculation = "无人口数据，使用默认评分50分"
                reliability = "none"
            else:
                # 计算犯罪率（每千人犯罪数）
                crime_rate = (total_crimes / population) * 1000
                
                # 基于犯罪率的安全评分
                if crime_rate <= 20:
                    safety_score = 95.0
                elif crime_rate <= 30:
                    safety_score = 85.0
                elif crime_rate <= 50:
                    safety_score = 75.0
                elif crime_rate <= 80:
                    safety_score = 60.0
                elif crime_rate <= 120:
                    safety_score = 45.0
                elif crime_rate <= 200:
                    safety_score = 30.0
                else:
                    safety_score = 15.0
                
                calculation = f"犯罪率{crime_rate:.2f}/1000人，评分{safety_score}分"
                reliability = "high" if population >= 100 else "medium"
            
            return {
                'score': safety_score,
                'crime_rate': round(crime_rate, 2),
                'total_crimes': total_crimes,
                'population': population,
                'calculation': calculation,
                'data_reliability': reliability
            }
    
    except Exception as e:
        logger.error(f"计算安全评分时出错: {str(e)}")
        return {
            'score': 50.0, 
            'crime_rate': 0, 
            'total_crimes': 0, 
            'population': 0,
            'calculation': f'数据获取失败: {str(e)}',
            'data_reliability': 'none'
        }
    finally:
        if connection:
            connection.close()

def calculate_cost_of_living_score(house_price):
    """
    计算生活成本评分
    基于房价计算，房价越低分数越高
    """
    if house_price == 0:
        return {'score': 50.0, 'house_price': 0, 'calculation': '默认值（房价数据缺失）'}
    
    # 房价分档评分
    if house_price < 500000:
        score = 95
        tier = "<50万"
    elif house_price < 750000:
        score = 80
        tier = "50-75万"
    elif house_price < 1000000:
        score = 65
        tier = "75-100万"
    elif house_price < 1500000:
        score = 50
        tier = "100-150万"
    elif house_price < 2000000:
        score = 35
        tier = "150-200万"
    else:
        score = 20
        tier = ">200万"
    
    return {
        'score': float(score),
        'house_price': house_price,
        'price_tier': tier,
        'calculation': f"房价${int(house_price):,}属于{tier}档，评分{score}分"
    }

def calculate_transport_score(sal_code):
    """
    计算交通评分
    基于交通站点数量，站点越多分数越高
    """
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 查询交通站点数据
            sql = """
            SELECT 
                COUNT(*) as total_stops,
                SUM(CASE WHEN MODE LIKE %s THEN 1 ELSE 0 END) as train_stops,
                SUM(CASE WHEN MODE LIKE %s THEN 1 ELSE 0 END) as tram_stops,
                SUM(CASE WHEN MODE LIKE %s THEN 1 ELSE 0 END) as bus_stops
            FROM epic3_transport_stops 
            WHERE SAL_CODE21 = %s
            """
            cursor.execute(sql, ('%TRAIN%', '%TRAM%', '%BUS%', sal_code))
            result = cursor.fetchone()
            
            total_stops = int(result['total_stops'] or 0)
            train_stops = int(result['train_stops'] or 0)
            tram_stops = int(result['tram_stops'] or 0)
            bus_stops = int(result['bus_stops'] or 0)
            
            # 加权评分：火车站权重最高，电车次之，公交最低
            weighted_score = (train_stops * 15 + tram_stops * 10 + bus_stops * 5 + 
                            (total_stops - train_stops - tram_stops - bus_stops) * 3)
            
            transport_score = min(100, weighted_score)
            
            return {
                'score': float(transport_score),
                'total_stops': total_stops,
                'stops_breakdown': {
                    'train': train_stops,
                    'tram': tram_stops,
                    'bus': bus_stops,
                    'other': total_stops - train_stops - tram_stops - bus_stops
                },
                'calculation': f"加权评分: 火车{train_stops}×15 + 电车{tram_stops}×10 + 公交{bus_stops}×5 = {weighted_score}，上限100分"
            }
    except Exception as e:
        logger.error(f"计算交通评分时出错: {str(e)}")
        return {'score': 0.0, 'total_stops': 0, 'calculation': f'数据获取失败: {str(e)}'}
    finally:
        if connection:
            connection.close()

def calculate_child_care_score(sal_code):
    """
    计算孩子保障评分
    基于学校数量和儿童服务数量
    """
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 查询学校数量
            sql_schools = """
            SELECT COUNT(*) as school_count
            FROM epic3_schools 
            WHERE SAL_CODE21 = %s
            """
            cursor.execute(sql_schools, (sal_code,))
            schools_result = cursor.fetchone()
            school_count = int(schools_result['school_count'] or 0)
            
            # 查询儿童服务数量
            sql_childcare = """
            SELECT COUNT(*) as childcare_count
            FROM epic3_early_childhood_services 
            WHERE SAL_CODE21 = %s
            """
            cursor.execute(sql_childcare, (sal_code,))
            childcare_result = cursor.fetchone()
            childcare_count = int(childcare_result['childcare_count'] or 0)
            
            # 孩子保障评分计算
            school_score = min(60, school_count * 12)
            childcare_score = min(40, childcare_count * 8)
            total_score = school_score + childcare_score
            
            return {
                'score': float(total_score),
                'school_count': school_count,
                'childcare_count': childcare_count,
                'breakdown': {
                    'school_score': school_score,
                    'childcare_score': childcare_score
                },
                'calculation': f"学校{school_count}所×12分 + 儿童服务{childcare_count}个×8分 = {total_score}分"
            }
    except Exception as e:
        logger.error(f"计算孩子保障评分时出错: {str(e)}")
        return {'score': 0.0, 'school_count': 0, 'childcare_count': 0, 'calculation': f'数据获取失败: {str(e)}'}
    finally:
        if connection:
            connection.close()

def calculate_industry_score(sal_code, industry_name):
    """
    计算行业评分
    基于指定行业在该地区的就业人数
    """
    connection = None
    try:
        connection = pymysql.connect(**DB_CONFIG)
        with connection.cursor() as cursor:
            # 获取对应的SA2编码
            sql_mapping = """
            SELECT SA2_CODE21 
            FROM epic3_mapping_sa2_sal 
            WHERE SAL_CODE21 = %s
            LIMIT 1
            """
            cursor.execute(sql_mapping, (sal_code,))
            mapping_result = cursor.fetchone()
            
            if mapping_result:
                sa2_code = mapping_result['SA2_CODE21']
                
                # 查询指定行业的就业数据
                sql_industry = """
                SELECT 
                    `1_4 Employees`, `5_19 Employees`, 
                    `20_199 Employees`, `200 plus Employees`
                FROM epic3_industry_employment 
                WHERE SA2_CODE21 = %s AND Industry = %s
                """
                cursor.execute(sql_industry, (sa2_code, industry_name))
                industry_result = cursor.fetchone()
                
                if industry_result:
                    # 估算就业人数（使用中位数估算）
                    emp_1_4 = int(industry_result['1_4 Employees'] or 0)
                    emp_5_19 = int(industry_result['5_19 Employees'] or 0)
                    emp_20_199 = int(industry_result['20_199 Employees'] or 0)
                    emp_200_plus = int(industry_result['200 plus Employees'] or 0)
                    
                    estimated_employment = (emp_1_4 * 2.5 + emp_5_19 * 12 + 
                                          emp_20_199 * 100 + emp_200_plus * 300)
                    
                    # 行业评分：基于就业人数对数函数，避免线性增长过快
                    if estimated_employment == 0:
                        industry_score = 0
                    elif estimated_employment < 10:
                        industry_score = 20
                    elif estimated_employment < 50:
                        industry_score = 40
                    elif estimated_employment < 200:
                        industry_score = 60
                    elif estimated_employment < 500:
                        industry_score = 80
                    else:
                        industry_score = 100
                    
                    return {
                        'score': float(industry_score),
                        'estimated_employment': int(estimated_employment),
                        'business_breakdown': {
                            '1_4_employees': emp_1_4,
                            '5_19_employees': emp_5_19,
                            '20_199_employees': emp_20_199,
                            '200_plus_employees': emp_200_plus
                        },
                        'calculation': f"估算就业人数{int(estimated_employment)}人，评分{industry_score}分"
                    }
            
            return {
                'score': 0.0,
                'estimated_employment': 0,
                'calculation': f"该地区无{industry_name}行业数据"
            }
    except Exception as e:
        logger.error(f"计算行业评分时出错: {str(e)}")
        return {'score': 0.0, 'estimated_employment': 0, 'calculation': f'数据获取失败: {str(e)}'}
    finally:
        if connection:
            connection.close()

def calculate_overall_score(scores):
    """
    计算综合评分
    使用权重加权平均
    """
    overall = (scores['safety']['score'] * SCORING_WEIGHTS['safety'] +
               scores['cost_of_living']['score'] * SCORING_WEIGHTS['cost_of_living'] +
               scores['transport']['score'] * SCORING_WEIGHTS['transport'] +
               scores['child_care']['score'] * SCORING_WEIGHTS['child_care'] +
               scores['industry']['score'] * SCORING_WEIGHTS['industry'])
    
    return round(overall, 1)

def score_suburb(event, context):
    """
    主要的API处理函数
    """
    # 处理CORS预检请求
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': ''
        }
    
    try:
        # 解析请求体
        body = json.loads(event['body'])
        suburb_name = body.get('sub')
        industry_name = body.get('industry')
        
        # 验证必需参数
        if not suburb_name or not industry_name:
            return error_response(400, 'MISSING_PARAMS', 
                               'suburb (sub) 和 industry 参数是必需的')
        
        logger.info(f"开始计算评分: suburb={suburb_name}, industry={industry_name}")
        
        # 1. 获取SAL_CODE21和房价数据
        suburb_data = get_sal_code_by_suburb(suburb_name)
        if not suburb_data:
            return error_response(404, 'SUBURB_NOT_FOUND', 
                               f'未找到地区: {suburb_name}')
        
        sal_code = suburb_data['sal_code']
        house_price = suburb_data['house_price_2024']
        
        logger.info(f"找到地区数据: SAL_CODE21={sal_code}, 房价=${house_price}")
        
        # 2. 计算各项评分
        safety_score = calculate_safety_score(sal_code)
        cost_score = calculate_cost_of_living_score(house_price)
        transport_score = calculate_transport_score(sal_code)
        child_care_score = calculate_child_care_score(sal_code)
        industry_score = calculate_industry_score(sal_code, industry_name)
        
        # 3. 组装评分数据
        scores = {
            'safety': safety_score,
            'cost_of_living': cost_score,
            'transport': transport_score,
            'child_care': child_care_score,
            'industry': industry_score
        }
        
        # 4. 计算综合评分
        overall_score = calculate_overall_score(scores)
        
        # 5. 构建响应数据
        result = {
            'suburb': suburb_name,
            'industry': industry_name,
            'sal_code': sal_code,
            'algorithm_version': '3.0_with_population_crime_rate',
            'scores': {
                'safety': safety_score['score'],
                'cost_of_living': cost_score['score'],
                'transport': transport_score['score'],
                'child_care': child_care_score['score'],
                'industry': industry_score['score'],
                'overall': overall_score
            },
            'detailed_breakdown': scores,
            'scoring_weights': SCORING_WEIGHTS,
            'summary': {
                'house_price_2024': house_price,
                'population': safety_score.get('population', 0),
                'crime_rate_per_1000': safety_score.get('crime_rate', 0),
                'total_transport_stops': transport_score.get('total_stops', 0),
                'total_schools': child_care_score.get('school_count', 0),
                'total_childcare_services': child_care_score.get('childcare_count', 0),
                'estimated_industry_employment': industry_score.get('estimated_employment', 0),
                'data_quality_notes': {
                    'safety_reliability': safety_score.get('data_reliability', 'unknown')
                }
            }
        }
        
        logger.info(f"评分计算完成: 综合评分={overall_score}")
        return success_response(result)
        
    except json.JSONDecodeError:
        return error_response(400, 'INVALID_JSON', '请求体必须是有效的JSON格式')
    except Exception as e:
        logger.error(f"API处理错误: {str(e)}")
        return error_response(500, 'INTERNAL_ERROR', f'服务器内部错误: {str(e)}')

def success_response(data):
    """返回成功响应"""
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': True,
            'data': data
        }, ensure_ascii=False)
    }

def error_response(status_code, error_code, message):
    """返回错误响应"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'success': False,
            'error': {
                'code': error_code,
                'message': message
            }
        }, ensure_ascii=False)
    }