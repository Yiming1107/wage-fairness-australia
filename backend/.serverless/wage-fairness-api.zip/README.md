# wage-fairness-australia
A data-driven platform to empower Australian workers with transparent wage fairness assessment tools
